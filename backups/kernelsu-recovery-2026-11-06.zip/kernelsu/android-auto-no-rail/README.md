# Android Auto: ocultar la barra horizontal

Módulo experimental de KernelSU. Instala un overlay de recursos desde la
partición `product`; no reemplaza ni vuelve a firmar el APK de Google. El
`OverlayConfig` conserva los estados de los 43 RRO de producto del A54 observados
al construir el módulo y habilita este overlay nuevo.

El overlay lleva `dimen/car_rail_height` y `dimen/cielo_rail_height` de 80 dp a
0 dp. No cambia la barra lateral vertical ni los controles multimedia
independientes. Está apuntado a Android Auto 18.1; Google puede cambiar estos
recursos en una actualización y entonces habrá que revisar el APK de nuevo.

## Revertir

Deshabilita o desinstala `Nemotron Android Auto No Rail` en KernelSU y reinicia.
El módulo solo aporta un RRO para Android Auto; si el overlay no es compatible,
el teléfono y las demás apps siguen arrancando sin ese cambio.
